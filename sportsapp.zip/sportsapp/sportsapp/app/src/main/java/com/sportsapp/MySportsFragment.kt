package com.sportsapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation

class MySportsFragment : Fragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.fragment_my_sports, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<android.widget.Button>(R.id.button_basketball)?.setOnClickListener {
            Navigation.findNavController(it).navigate(R.id.action_mySportsFragment_to_basketballFragment)
        }
        view.findViewById<android.widget.Button>(R.id.button_football)?.setOnClickListener {
            Navigation.findNavController(it).navigate(R.id.action_mySportsFragment_to_footballFragment)
        }
        view.findViewById<android.widget.Button>(R.id.button_tennis)?.setOnClickListener {
            Navigation.findNavController(it).navigate(R.id.action_mySportsFragment_to_tennisFragment)
        }
        view.findViewById<android.widget.Button>(R.id.button_swimming)?.setOnClickListener {
            Navigation.findNavController(it).navigate(R.id.action_mySportsFragment_to_swimmingFragment)
        }
        view.findViewById<android.widget.Button>(R.id.button_soccer)?.setOnClickListener {
            Navigation.findNavController(it).navigate(R.id.action_mySportsFragment_to_soccerFragment)
        }
    }
}
