package com.sportsapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.sportsapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Use the custom toolbar instead of the default ActionBar
        setSupportActionBar(binding.toolbar)

        // ✅ Correct way to get the NavController in an Activity
        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController

        // Define top-level destinations (no back button on these)
        val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.homeFragment,
                R.id.accountFragment,
                R.id.profileFragment,
                R.id.mySportsFragment
            )
        )

        // Setup ActionBar with NavController
        setupActionBarWithNavController(navController, appBarConfiguration)

        // ✅ FIX: use binding.bottomNavigation (camelCase from viewBinding)
        binding.bottomNavigation.setupWithNavController(navController)

        // Change title dynamically based on the destination
        navController.addOnDestinationChangedListener { _, destination, _ ->
            when (destination.id) {
                R.id.homeFragment -> binding.toolbar.title = "Home"
                R.id.accountFragment -> binding.toolbar.title = "Account"
                R.id.profileFragment -> binding.toolbar.title = "Profile"
                R.id.mySportsFragment -> binding.toolbar.title = "My Sports"
                R.id.basketballFragment -> binding.toolbar.title = "Basketball"
                R.id.footballFragment -> binding.toolbar.title = "Football"
                R.id.tennisFragment -> binding.toolbar.title = "Tennis"
                R.id.swimmingFragment -> binding.toolbar.title = "Swimming"
                R.id.soccerFragment -> binding.toolbar.title = "Soccer"
            }
        }
    }

    // Handle back navigation with the ActionBar
    override fun onSupportNavigateUp(): Boolean {
        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}
